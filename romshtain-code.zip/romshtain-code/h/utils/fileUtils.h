
#pragma once

#include "stringUtils.h"

void loadFile(string filepath, string& contents);
void writeFile(string filepath, const string& contents);

