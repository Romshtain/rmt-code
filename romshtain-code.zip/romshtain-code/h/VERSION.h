#pragma once

// the version of romshtain is vX.Y.Y

const int VERSION_X=0;
const int VERSION_Y=5;
const int VERSION_Z=1;
