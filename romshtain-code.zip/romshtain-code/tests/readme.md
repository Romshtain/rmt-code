This directory holds all tests for the Romshtain language. To run tests, open the parent directory in terminal and run
`./romshtain tests/run_tests.rmt`. It is important that your current working directory is the parent directory and that there is a romshtain executable in the parent directory called `romshtain`.
