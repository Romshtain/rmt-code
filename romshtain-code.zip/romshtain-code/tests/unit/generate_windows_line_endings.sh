printf '# Romshtain Windows line endings test\r\nprint: "good\n_____"\r\n\r\nprint: "good"' > windows_line_endings.rmt

