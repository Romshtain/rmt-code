These are some examples of working Romshtain source code
